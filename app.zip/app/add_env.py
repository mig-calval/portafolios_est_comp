import os
os.environ["PGPASS"] = "postgres"
os.environ["PGUSR"] = "postgres"
